import Main from "./main.js";
new Main();