//var HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path'); 

module.exports = { 
mode: 'development',
//devtool: "none",
//mode: 'production',
entry: './src/index.js', 
output: { 
path: path.resolve(__dirname, 'build'), 
filename: 'bundle.js' },

//plugins: [new HtmlWebpackPlugin()],






};